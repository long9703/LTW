@extends('layouts.master')

@section('title', 'Chi tiết sản phẩm')

@section('content')
<div class="container py-5">
    <div class="row">
        {{-- Ảnh sản phẩm --}}
        <div class="col-md-6">
            <img src="{{ asset('images/product1.jpg') }}" class="img-fluid rounded" alt="Dumbbell">
        </div>

        {{-- Thông tin sản phẩm --}}
        <div class="col-md-6">
            <h2 class="fw-bold">Tạ tay cao cấp 10kg</h2>
            <p class="text-muted">SKU: GYM1001</p>
            <h4 class="text-danger mb-3">250,000 VNĐ</h4>
            <p>Mô tả sản phẩm: Tạ tay chất liệu cao su bọc sắt, phù hợp luyện tập tại nhà và phòng gym chuyên nghiệp.</p>

            {{-- Số lượng & tạm tính --}}
            <div class="mb-3">
                <label for="quantity" class="form-label">Số lượng:</label>
                <input type="number" class="form-control w-25" id="quantity" value="1" min="1" onchange="updateSubtotal()">
            </div>

            <p><strong>Tạm tính:</strong> <span id="subtotal">250,000 VNĐ</span></p>

            <button class="btn btn-primary" onclick="addToCart()">
                <i class="bi bi-cart-plus me-1"></i> Thêm vào giỏ hàng
            </button>
        </div>
    </div>

    {{-- Mô tả chi tiết --}}
    <div class="mt-5">
        <h4>Chi tiết sản phẩm</h4>
        <p>
            - Chất liệu cao cấp, độ bền cao <br>
            - Tay cầm chống trơn trượt, dễ dàng sử dụng <br>
            - Sản phẩm phù hợp mọi đối tượng <br>
            - Bảo hành 6 tháng
        </p>
    </div>
</div>
@endsection

@push('scripts')
<script>
    const unitPrice = 250000;

    function formatCurrency(amount) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(amount);
    }

    function updateSubtotal() {
        const qty = parseInt(document.getElementById('quantity').value) || 1;
        const subtotal = qty * unitPrice;
        document.getElementById('subtotal').textContent = formatCurrency(subtotal);
    }

    function addToCart() {
        const qty = parseInt(document.getElementById('quantity').value) || 1;
        alert(`🛒 Đã thêm ${qty} sản phẩm vào giỏ hàng!`);
        
    }

    // Tính giá ban đầu khi load
    updateSubtotal();
</script>
@endpush
