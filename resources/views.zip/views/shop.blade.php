@extends('layouts.master')
@section('page-title', 'Sản Phẩm')
@section('content')
<div class="container">
    

    <div class="row">
        <!-- Sidebar lọc sản phẩm -->
        <div class="col-md-3">
            <h5>Danh mục</h5>
            <ul class="list-group">
                <li class="list-group-item"><a href="#">Tất cả</a></li>
                <li class="list-group-item"><a href="#">Áo tập</a></li>
                <li class="list-group-item"><a href="#">Quần tập</a></li>
                <li class="list-group-item"><a href="#">Tạ đơn</a></li>
                <li class="list-group-item"><a href="#">Máy tập</a></li>
                <li class="list-group-item"><a href="#">Thực phẩm bổ sung</a></li>
                <li class="list-group-item"><a href="#">Phụ kiện</a></li>
                <li class="list-group-item"><a href="#">Khác</a></li>
            </ul>

            <hr>

            <!-- Lọc theo giá -->
            <h5>Giá</h5>
            <input type="range" class="form-range" id="priceRange" min="0" max="10000000" step="10000">
            <label for="priceRange">0 - 10000000 VNĐ</label>

            <hr>

            <!-- Lọc theo Thương hiệu -->
            <h5>Thương hiệu</h5>
            <select class="form-select" id="brandSelect">
                <option value="">Tất cả</option>
                <option value="brand1">Thương hiệu 1</option>
                <option value="brand2">Thương hiệu 2</option>
            </select>
        </div>

        <!-- Nội dung sản phẩm -->
        <div class="col-md-9">
            <div class="d-flex flex-wrap justify-content-start">
                <!-- Sản phẩm nổi bật -->
                <h3 class="text-center mb-4 w-100">Sản phẩm nổi bật</h3>

                <div class="row" id="product-list">
                    <!-- Sản phẩm mẫu -->
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="{{ asset('images/product1.jpg') }}" class="card-img-top" alt="product-image">
                            <div class="card-body">
                                <h5 class="card-title">Mũ tập Form đẹp</h5>
                                <p class="card-text">500,000 VNĐ</p>
                                <a href="product-detail" class="btn btn-primary">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="{{ asset('images/product1.jpg') }}" class="card-img-top" alt="product-image">
                            <div class="card-body">
                                <h5 class="card-title">Mũ tập Form đẹp</h5>
                                <p class="card-text">500,000 VNĐ</p>
                                <a href="product-detail" class="btn btn-primary">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="{{ asset('images/product1.jpg') }}" class="card-img-top" alt="product-image">
                            <div class="card-body">
                                <h5 class="card-title">Mũ tập Form đẹp</h5>
                                <p class="card-text">500,000 VNĐ</p>
                                <a href="product-detail" class="btn btn-primary">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="{{ asset('images/product1.jpg') }}" class="card-img-top" alt="product-image">
                            <div class="card-body">
                                <h5 class="card-title">Mũ tập Form đẹp</h5>
                                <p class="card-text">500,000 VNĐ</p>
                                <a href="product-detail" class="btn btn-primary">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="{{ asset('images/product1.jpg') }}" class="card-img-top" alt="product-image">
                            <div class="card-body">
                                <h5 class="card-title">Mũ tập Form đẹp</h5>
                                <p class="card-text">500,000 VNĐ</p>
                                <a href="product-detail" class="btn btn-primary">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="{{ asset('images/product1.jpg') }}" class="card-img-top" alt="product-image">
                            <div class="card-body">
                                <h5 class="card-title">Mũ tập Form đẹp</h5>
                                <p class="card-text">500,000 VNĐ</p>
                                <a href="product-detail" class="btn btn-primary">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Phân trang tĩnh -->
                <div class="d-flex justify-content-center mt-4">
                    <ul class="pagination">
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('scripts')
<script>
    // Xử lý chuyển đổi giữa grid và list view
    document.getElementById('grid-view').addEventListener('click', function() {
        document.getElementById('product-list').classList.remove('list-view');
        document.getElementById('product-list').classList.add('grid-view');
    });

    document.getElementById('list-view').addEventListener('click', function() {
        document.getElementById('product-list').classList.remove('grid-view');
        document.getElementById('product-list').classList.add('list-view');
    });
</script>

<style>
    /* Mặc định: hiển thị theo lưới */
    .grid-view .card {
        display: block;
    }

    /* Chế độ danh sách: card sẽ có chiều rộng đầy đủ */
    .list-view .card {
        display: flex;
        flex-direction: row;
        width: 100%;
    }

    /* Tùy chỉnh khác cho chế độ danh sách */
    .list-view .card-img-top {
        width: 150px;
        height: 150px;
        object-fit: cover;
        margin-right: 20px;
    }

    .list-view .card-body {
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
</style>
@endsection
