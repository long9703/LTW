{{-- resources/views/auth/register.blade.php --}}
@extends('layouts.master')

@section('title', 'Đăng ký')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h2 class="mb-4 text-center">Đăng ký tài khoản</h2>

            {{-- Form đăng ký --}}
            <form action="{{ route('register') }}" method="POST" id="register-form">
                @csrf

                {{-- Tên người dùng --}}
                <div class="mb-3">
                    <label for="name" class="form-label">Tên người dùng</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                    <div class="invalid-feedback" id="name-error"></div>
                </div>

                {{-- Email --}}
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                    <div class="invalid-feedback" id="email-error"></div>
                </div>

                {{-- Mật khẩu --}}
                <div class="mb-3">
                    <label for="password" class="form-label">Mật khẩu</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                    <div class="invalid-feedback" id="password-error"></div>
                </div>

                {{-- Xác nhận mật khẩu --}}
                <div class="mb-3">
                    <label for="password_confirmation" class="form-label">Xác nhận mật khẩu</label>
                    <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required>
                    <div class="invalid-feedback" id="password-confirmation-error"></div>
                </div>

                {{-- Nút đăng ký --}}
                <button type="submit" class="btn btn-primary w-100">Đăng ký</button>
            </form>

            
            <p class="mt-3 text-center">
                Bạn đã có tài khoản? <a href="{{ route('login') }}">Đăng nhập</a>
            </p>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    // Hàm xác nhận mật khẩu
    function validateForm() {
        let isValid = true;

        // Xóa lỗi trước khi kiểm tra lại
        clearErrors();

        // Kiểm tra tên người dùng
        const name = document.getElementById('name');
        if (name.value.trim() === '') {
            isValid = false;
            document.getElementById('name-error').textContent = 'Tên người dùng không được để trống.';
            name.classList.add('is-invalid');
        } else {
            name.classList.remove('is-invalid');
        }

        // Kiểm tra email
        const email = document.getElementById('email');
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        if (email.value.trim() === '') {
            isValid = false;
            document.getElementById('email-error').textContent = 'Email không được để trống.';
            email.classList.add('is-invalid');
        } else if (!emailPattern.test(email.value)) {
            isValid = false;
            document.getElementById('email-error').textContent = 'Email không hợp lệ.';
            email.classList.add('is-invalid');
        } else {
            email.classList.remove('is-invalid');
        }

        // Kiểm tra mật khẩu
        const password = document.getElementById('password');
        if (password.value.trim() === '') {
            isValid = false;
            document.getElementById('password-error').textContent = 'Mật khẩu không được để trống.';
            password.classList.add('is-invalid');
        } else {
            password.classList.remove('is-invalid');
        }

        // Kiểm tra xác nhận mật khẩu
        const passwordConfirmation = document.getElementById('password_confirmation');
        if (passwordConfirmation.value.trim() !== password.value.trim()) {
            isValid = false;
            document.getElementById('password-confirmation-error').textContent = 'Mật khẩu xác nhận không khớp.';
            passwordConfirmation.classList.add('is-invalid');
        } else {
            passwordConfirmation.classList.remove('is-invalid');
        }

        return isValid;
    }

    // Hàm xóa lỗi
    function clearErrors() {
        document.getElementById('name-error').textContent = '';
        document.getElementById('email-error').textContent = '';
        document.getElementById('password-error').textContent = '';
        document.getElementById('password-confirmation-error').textContent = '';

        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            input.classList.remove('is-invalid');
        });
    }

    // Xử lý khi form submit
    document.getElementById('register-form').addEventListener('submit', function(event) {
        if (!validateForm()) {
            event.preventDefault();  // Ngừng gửi form nếu có lỗi
        }
    });
</script>
@endpush
