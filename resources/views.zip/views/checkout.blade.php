@extends('layouts.master')

@section('content')
<div class="container my-5">
    <h2 class="mb-4">Thanh toán</h2>
    <div class="row">
        <!-- Form thông tin người nhận -->
        <div class="col-md-7">
            <div class="card p-4">
                <h4>Thông tin nhận hàng</h4>
                <form id="checkout-form">
                    <div class="mb-3">
                        <label for="fullname" class="form-label">Họ và tên</label>
                        <input type="text" class="form-control" id="fullname" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Số điện thoại</label>
                        <input type="tel" class="form-control" id="phone" required>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Địa chỉ nhận hàng</label>
                        <textarea class="form-control" id="address" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="note" class="form-label">Ghi chú (không bắt buộc)</label>
                        <textarea class="form-control" id="note" rows="2"></textarea>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tóm tắt đơn hàng -->
        <div class="col-md-5">
            <div class="card p-4 bg-light">
                <h4>Đơn hàng của bạn</h4>
                <ul class="list-group mb-3">
                    <li class="list-group-item d-flex justify-content-between lh-sm">
                        <div>
                            <h6 class="my-0">Áo tập GYM PRO</h6>
                            <small class="text-muted">x1</small>
                        </div>
                        <span class="text-muted">250,000 VNĐ</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between lh-sm">
                        <div>
                            <h6 class="my-0">Quần tập nam LID</h6>
                            <small class="text-muted">x2</small>
                        </div>
                        <span class="text-muted">640,000 VNĐ</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Tạm tính</span>
                        <strong>890,000 VNĐ</strong>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Phí vận chuyển</span>
                        <strong>30,000 VNĐ</strong>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Tổng thanh toán</span>
                        <strong class="text-danger">920,000 VNĐ</strong>
                    </li>
                </ul>

                <button type="button" class="btn btn-success w-100" onclick="submitCheckout()">Xác nhận đặt hàng</button>

            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function submitCheckout() {
        const fullname = document.getElementById('fullname').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const address = document.getElementById('address').value.trim();

        if (!fullname || !phone || !address) {
            alert('Vui lòng điền đầy đủ thông tin nhận hàng!');
            return;
        }

        alert('🎉 Đặt hàng thành công!\nCảm ơn bạn đã mua hàng tại HLT SHOP!');

        // Quay về trang chủ sau 1 giây
        setTimeout(() => {
            window.location.href = '/';
        }, 1000);
    }
</script>
@endpush