<!-- resources/views/admin/users/index.blade.php -->
@extends('layouts.admin')

@section('content')
    <h1>User List</h1>
    

    <table class="table mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @php
                $users = [
                    ['id' => 1, 'name' => 'Long', 'email' => '3@example.com'],
                    ['id' => 2, 'name' => 'LongThanh', 'email' => '3e@example.com'],
                    ['id' => 3, 'name' => 'NguyenLong', 'email' => '1@example.com'],
                ];
            @endphp
            @foreach($users as $user)
                <tr>
                    <td>{{ $user['id'] }}</td>
                    <td>{{ $user['name'] }}</td>
                    <td>{{ $user['email'] }}</td>
                    <td>
                        <a href="{{ route('admin.users.show', $user['id']) }}" class="btn btn-info btn-sm">View</a>
                        <a href="{{ route('admin.users.edit', $user['id']) }}" class="btn btn-warning btn-sm">Edit</a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
