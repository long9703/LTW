@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Orders List</h1>
        <!-- Danh sách Orders -->
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Lặp qua danh sách orders (ví dụ ở đây chỉ là mẫu) -->
                <tr>
                    <td>1</td>
                    <td>#1001</td>
                    <td>John Doe</td>
                    <td>Pending</td>
                    <td><a href="{{ route('admin.orders.show', 1) }}">View</a></td>
                </tr>
                <!-- Thêm nhiều bản ghi tương tự -->
            </tbody>
        </table>
    </div>
@endsection
