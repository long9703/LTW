@extends('layouts.admin')

@section('content')
<div class="container mt-4">
    <h2>Add New Category</h2>

    <form id="categoryForm">
        <div class="form-group">
            <label for="categoryName">Category Name</label>
            <input type="text" class="form-control" id="categoryName" placeholder="Enter category name">
        </div>

        <button type="submit" class="btn btn-success">Save Category</button>
    </form>
</div>

@endsection

@push('scripts')
<script>
    document.getElementById('categoryForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const categoryName = document.getElementById('categoryName').value;

        // Normally, you would send an AJAX request here to save the new category
        console.log('New category added:', categoryName);

        // Redirect to categories index after saving (mocked)
        alert('Category added!');
        window.location.href = "{{ route('admin.categories.index') }}";
    });
</script>
@endpush
