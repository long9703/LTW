@extends('layouts.admin')

@section('content')
<div class="container mt-4">
    <h2>Categories</h2>
    <a href="{{ route('admin.categories.create') }}" class="btn btn-primary mb-3">Add New Category</a>

    <!-- Table to display categories -->
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Category Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="categories-table">
            <!-- Example Row -->
            <tr>
                <td>1</td>
                <td>Fitness</td>
                <td>
                    <a href="#" class="btn btn-warning btn-sm edit-btn">Edit</a>
                    <a href="#" class="btn btn-danger btn-sm delete-btn">Delete</a>
                </td>
            </tr>
            <!-- More categories rows will go here -->
        </tbody>
    </table>
</div>

<!-- Modal for Editing or Adding Category -->
<div class="modal" id="categoryModal" tabindex="-1" role="dialog" aria-labelledby="categoryModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="categoryModalLabel">Edit Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="categoryForm">
          <div class="form-group">
            <label for="categoryName">Category Name</label>
            <input type="text" class="form-control" id="categoryName" placeholder="Enter category name">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="saveCategory">Save changes</button>
      </div>
    </div>
  </div>
</div>

@endsection

@push('scripts')
<script>
    // JavaScript for handling category editing
    document.addEventListener('DOMContentLoaded', function () {
        const editButtons = document.querySelectorAll('.edit-btn');
        const deleteButtons = document.querySelectorAll('.delete-btn');
        const saveButton = document.getElementById('saveCategory');
        const categoryNameInput = document.getElementById('categoryName');
        let editingCategory = null;

        // Handle editing a category
        editButtons.forEach(button => {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                const row = event.target.closest('tr');
                const categoryId = row.querySelector('td').innerText;
                const categoryName = row.querySelector('td:nth-child(2)').innerText;
                
                categoryNameInput.value = categoryName;
                editingCategory = categoryId;

                $('#categoryModal').modal('show');
            });
        });

        // Handle saving the category
        saveButton.addEventListener('click', function () {
            const updatedCategoryName = categoryNameInput.value;
            if (editingCategory) {
                // Normally, send an AJAX request to update the category in the database
                console.log('Updating category', editingCategory, 'with new name:', updatedCategoryName);

                // Update the row with new category name
                const row = document.querySelector(`tr td:contains(${editingCategory})`).closest('tr');
                row.querySelector('td:nth-child(2)').innerText = updatedCategoryName;
            }
            $('#categoryModal').modal('hide');
        });

        // Handle deleting a category
        deleteButtons.forEach(button => {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                const row = event.target.closest('tr');
                row.remove();
                alert("Category deleted!");
            });
        });
    });
</script>
@endpush
