@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Products</h1>
        <a href="{{ route('admin.products.create') }}" class="btn btn-primary mb-3">Create New Product</a>
        <!-- Danh sách Products -->
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Protein Powder</td>
                    <td>$30</td>
                    <td><a href="{{ route('admin.products.edit', 1) }}">Edit</a> | <a href="{{ route('admin.products.show', 1) }}">View</a></td>
                </tr>
            </tbody>
        </table>
    </div>
@endsection
