<!-- partials/footer.blade.php -->
<footer class="bg-dark text-white py-4">
    <div class="container text-center">
        <p>&copy; 2025 NTL Shop - Tất cả quyền được bảo lưu.</p>
        <ul class="list-inline">
            <li class="list-inline-item"><a href="#" class="text-white">Giới thiệu</a></li>
            <li class="list-inline-item"><a href="#" class="text-white">Chính sách bảo mật</a></li>
            <li class="list-inline-item"><a href="contact" class="text-white">Liên hệ</a></li>
        </ul>
    </div>
</footer>
