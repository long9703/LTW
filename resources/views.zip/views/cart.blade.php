@extends('layouts.master')

@section('content')
<div class="container">
    <h2 class="mb-4">Giỏ hàng</h2>
    <div class="row">
        <div class="col-lg-8">
            <table class="table table-bordered">
                <thead class="table-secondary">
                    <tr>
                        <th>Sản phẩm</th>
                        <th>Hình ảnh</th>
                        <th>Giá</th>
                        <th>Số lượng</th>
                        <th>Thành tiền</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {{-- Sản phẩm mẫu --}}
                    <tr>
                        <td>Áo tập GYM PRO</td>
                        <td><img src="{{ asset('images/products/shirt1.jpg') }}" alt="" width="60"></td>
                        <td>250,000 VNĐ</td>
                        <td><input type="number" class="form-control" value="1" min="1"></td>
                        <td>250,000 VNĐ</td>
                        <td><button class="btn btn-sm btn-danger">Xóa</button></td>
                    </tr>
                    <tr>
                        <td>Quần tập nam LID</td>
                        <td><img src="{{ asset('images/products/pants1.jpg') }}" alt="" width="60"></td>
                        <td>320,000 VNĐ</td>
                        <td><input type="number" class="form-control" value="2" min="1"></td>
                        <td>640,000 VNĐ</td>
                        <td><button class="btn btn-sm btn-danger">Xóa</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-lg-4">
            <div class="border p-3 rounded bg-light">
                <h4>Tóm tắt đơn hàng</h4>
                <hr>
                <div class="d-flex justify-content-between">
                    <span>Tạm tính:</span>
                    <strong id="subtotal">0 VNĐ</strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span>Phí vận chuyển:</span>
                    <strong>30,000 VNĐ</strong>
                </div>
                <hr>
                <div class="d-flex justify-content-between">
                    <span>Tổng thanh toán:</span>
                    <strong id="total" class="text-danger">0 VNĐ</strong>
                </div>
                <a href="{{ url('/checkout') }}" class="btn btn-primary w-100 mt-3">Tiến hành thanh toán</a>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function updateTotal() {
        let rows = document.querySelectorAll('tbody tr');
        let subtotal = 0;

        rows.forEach(row => {
            let priceCell = row.cells[2];
            let qtyInput = row.querySelector('input[type="number"]');
            let totalCell = row.cells[4];

            if (priceCell && qtyInput && totalCell) {
                let price = parseInt(priceCell.innerText.replace(/[^\d]/g, '')) || 0;
                let qty = parseInt(qtyInput.value) || 1;
                let total = price * qty;

                totalCell.innerText = total.toLocaleString('vi-VN') + ' VNĐ';
                subtotal += total;
            }
        });

        document.getElementById('subtotal').innerText = subtotal.toLocaleString('vi-VN') + ' VNĐ';
        let shipping = 30000;
        document.getElementById('total').innerText = (subtotal + shipping).toLocaleString('vi-VN') + ' VNĐ';
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('input[type="number"]').forEach(input => {
            input.addEventListener('input', updateTotal);
        });
        updateTotal(); // Gọi khi trang tải xong
    });
</script>

@endpush
